<ul class="sub-tabs pt-2">
    <li class="list-payment">
        <a href="all-payments">Payments Recieved</a>
    </li>
    <li class="list-due-payment bbd">
        <a href="due-payments">Due Payments</a>
    </li>
    <li class="list-overdue-payment">
        <a href="overdue-payments">Overdue Payments</a>
    </li>
    <li class="list-critical-payment">
        <a href="critical-payments">Critical Payments</a>
    </li>
    <li class="list-color">
        <a href="code-red">Code Red</a>
    </li>
</ul>
